interface MainFragmentListener {
    fun showSunImage()
    fun showMoonImage()
    fun showSeeImage()
}
