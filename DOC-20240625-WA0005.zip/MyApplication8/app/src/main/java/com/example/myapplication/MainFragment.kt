package com.example.myapplication

import MainFragmentListener
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.util.*

class MainFragment(mainActivity: MainActivity) : Fragment() {

    private lateinit var textView: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var tideTextViewRise: TextView
    private lateinit var tideTextViewFall: TextView

    // متغیرهای ذخیره میزان جزر و مد
    private val tideLevels = arrayOf(
        "مد: 50 cm", "جزر: 20 cm",
        "مد: 55 cm", "جزر: 25 cm",
        "مد: 60 cm", "جزر: 30 cm",
        "مد: 65 cm", "جزر: 35 cm",
        "مد: 70 cm", "جزر: 40 cm",
        "مد: 75 cm", "جزر: 45 cm",
        "مد: 80 cm", "جزر: 50 cm",
        "مد: 85 cm", "جزر: 55 cm",
        "مد: 90 cm", "جزر: 60 cm",
        "مد: 95 cm", "جزر: 65 cm",
        "مد: 100 cm", "جزر: 70 cm",
        "مد: 105 cm", "جزر: 75 cm"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_main, container, false)

        textView = view.findViewById(R.id.textView)
        seekBar = view.findViewById(R.id.seekBar)
        tideTextViewRise = view.findViewById(R.id.textViewRise)
        tideTextViewFall = view.findViewById(R.id.textViewFall)

        // تنظیم اولیه ساعت
        val calendar = Calendar.getInstance()
        val initialHour = calendar.get(Calendar.HOUR_OF_DAY)
        val initialMinute = calendar.get(Calendar.MINUTE)
        updateTimeText(initialHour, initialMinute)
        seekBar.progress = (initialHour * 2) + (initialMinute / 30)

        // تنظیم ماکسیمم مقدار SeekBar برای 24 ساعت (48 نیم ساعت)
        seekBar.max = 47

        // Listener برای تغییر ساعت
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val hour = progress / 2
                val minute = (progress % 2) * 30
                updateTimeText(hour, minute)
                updateTideText(hour)
                updateImage(hour)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // این متد زمانی فراخوانی می‌شود که کاربر لمس نوار را شروع می‌کند
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                // این متد زمانی فراخوانی می‌شود که کاربر لمس نوار را متوقف می‌کند
            }
        })

        return view
    }

    private fun updateTimeText(hour: Int, minute: Int) {
        val time = String.format("%02d:%02d", hour, minute)
        textView.text = time


    }

    private fun updateTideText(hour: Int) {
        val tideIndex = hour % tideLevels.size
        val tide = tideLevels[tideIndex]
        if (tide.startsWith("مد")) {
            tideTextViewRise.text = tide
            tideTextViewFall.text = ""
        } else {
            tideTextViewFall.text = tide
            tideTextViewRise.text = ""
        }
    }

    private fun updateImage(hour: Int) {
        val listener = activity as? MainFragmentListener
        listener?.apply {
            if (hour in 4..16) {
                showSeeImage()
            } else if (hour in 17..18) {
                showSunImage()
            } else {
                showMoonImage()
            }
        }
    }
}
