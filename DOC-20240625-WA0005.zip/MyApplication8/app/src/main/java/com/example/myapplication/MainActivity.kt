package com.example.myapplication

import MainFragmentListener
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity(), MainFragmentListener {

    private lateinit var mainFragment: MainFragment
    private lateinit var dateTextView: TextView
    private var currentPersianDate: PersianDate = PersianDate()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // مقداردهی به mainFragment و قرار دادن آن به عنوان fragment اولیه
        mainFragment = MainFragment(this) // ارسال این instance از MainActivity به عنوان listener
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, mainFragment)
            .commit()

        // مقداردهی به dateTextView و آیکون‌ها
        dateTextView = findViewById(R.id.dateTextView)
        val leftIcon = findViewById<ImageView>(R.id.leftIcon)
        val rightIcon = findViewById<ImageView>(R.id.rightIcon)

        // تنظیم تاریخ اولیه
        updateDateTextView()

        // تنظیم رویداد کلیک برای آیکون‌ها
        leftIcon.setOnClickListener { changeDate(-1) }
        rightIcon.setOnClickListener { changeDate(1) }
    }

    // به‌روزرسانی TextView تاریخ با استفاده از PersianDate
    private fun updateDateTextView() {
        dateTextView.text = currentPersianDate.toString()
    }

    // تغییر تاریخ
    private fun changeDate(days: Int) {
        currentPersianDate.addDays(days)
        updateDateTextView()
    }

    // متدهای Listener برای تغییر تصویر
    override fun showSunImage() {
        findViewById<ImageView>(R.id.cityImageView).setImageResource(R.drawable.sun)
    }

    override fun showMoonImage() {
        findViewById<ImageView>(R.id.cityImageView).setImageResource(R.drawable.moon)
    }

    override fun showSeeImage() {
        findViewById<ImageView>(R.id.cityImageView).setImageResource(R.drawable.see)
    }
}
