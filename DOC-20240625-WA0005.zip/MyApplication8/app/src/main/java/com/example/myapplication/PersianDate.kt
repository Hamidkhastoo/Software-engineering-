package com.example.myapplication

import java.util.Calendar

class PersianDate {
    private val calendar: Calendar = Calendar.getInstance()

    // آرایه‌ای از نام‌های ماه‌های شمسی
    private val persianMonths = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    init {
        updatePersianDate()
    }

    // افزودن روزها به تاریخ
    fun addDays(days: Int) {
        calendar.add(Calendar.DAY_OF_MONTH, days)
        updatePersianDate()
    }

    // به‌روزرسانی تاریخ شمسی با توجه به تاریخ میلادی
    private fun updatePersianDate() {
        val persianDate = toPersianDate(calendar)
        year = persianDate[0]
        month = persianDate[1]
        day = persianDate[2]
    }

    private var year: Int = 0
    private var month: Int = 0
    private var day: Int = 0

    // تبدیل تاریخ میلادی به شمسی
    private fun toPersianDate(calendar: Calendar): IntArray {
        val gregorianYear = calendar.get(Calendar.YEAR)
        val gregorianMonth = calendar.get(Calendar.MONTH) + 1
        val gregorianDay = calendar.get(Calendar.DAY_OF_MONTH)

        // الگوریتم تبدیل تاریخ میلادی به شمسی
        val persianYear: Int
        val persianMonth: Int
        val persianDay: Int

        val gregorianDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val persianDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

        val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
        val leapYearCorrection = if (isGregorianLeapYear(gregorianYear)) 1 else 0

        if (dayOfYear <= 79) {
            persianYear = gregorianYear - 622
            persianMonth = 10 + ((dayOfYear - 1) / 30)
            persianDay = (dayOfYear - 1) % 30 + 1
        } else {
            persianYear = gregorianYear - 621
            persianMonth = (dayOfYear - 79 + leapYearCorrection) / 30
            persianDay = (dayOfYear - 79 + leapYearCorrection) % 30 + 1
        }

        return intArrayOf(persianYear, persianMonth, persianDay)
    }

    // بررسی سال کبیسه میلادی
    private fun isGregorianLeapYear(year: Int): Boolean {
        return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0
    }

    // تبدیل کلاس به رشته برای نمایش
    override fun toString(): String {
        return "$day ${persianMonths[month - 1]} $year"
    }
}
